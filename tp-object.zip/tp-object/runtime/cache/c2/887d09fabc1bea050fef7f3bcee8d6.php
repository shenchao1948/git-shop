<?php
//000000000000
 exit();?>
a:9:{s:2:"id";s:3:"int";s:9:"room_code";s:6:"string";s:9:"room_name";s:6:"string";s:11:"create_user";s:3:"int";s:10:"user_count";s:3:"int";s:11:"create_time";s:8:"datetime";s:11:"uptate_time";s:8:"datetime";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}