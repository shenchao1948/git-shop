<?php
//000000000000
 exit();?>
a:15:{s:2:"id";s:3:"int";s:7:"user_ip";s:6:"string";s:9:"user_type";s:3:"int";s:9:"user_name";s:6:"string";s:8:"password";s:6:"string";s:10:"user_phone";s:6:"string";s:10:"user_email";s:6:"string";s:10:"user_token";s:6:"string";s:10:"user_login";s:8:"datetime";s:8:"user_out";s:8:"datetime";s:10:"user_state";s:3:"int";s:11:"create_time";s:8:"datetime";s:11:"update_time";s:8:"datetime";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}